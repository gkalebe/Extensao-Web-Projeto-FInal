import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import Register from "./pages/Register";

// Importa a imagem do logo. Caminho ajustado para './pages/assets/'
import vidaULogo from "./pages/assets/VidaU_logo.png";


// Importa os componentes de página completos para as rotas.
// É CRÍTICO que os nomes dos arquivos no disco (ex: "AlimentacaoSaudavel.js")
// correspondam EXATAMENTE à capitalização aqui.
import AlimentacaoSaudavel from "./pages/AlimentacaoSaudavel";
import DesconexaoDigital from "./pages/DesconexaoDigital";
import ExerciciosFisicos from "./pages/ExerciciosFisicos";
import EscritaPessoal from "./pages/EscritaPessoal";
import AtividadesCriativas from "./pages/AtividadesCriativas";
import RotinaSono from "./pages/RotinaSono";
import SocializacaoSaudavel from "./pages/SocializacaoSaudavel";
import OrganizacaoFinanceira from "./pages/OrganizacaoFinanceira";
import Meditacao from "./pages/Meditacao";
import Leitura from "./pages/Leitura";



// Componentes Placeholder (Nomes PascalCase para consistência)
const Navbar = () => <nav style={{ padding: '10px', background: '#F5ECD5' }}></nav>;
const NavbarLoader = () => <div style={{ textAlign: 'center', padding: '20px' }}>Carregando Navbar...</div>;



function App() {
  return (
    <Router>
     <div style={{ display: 'flex', minHeight: '100vh', backgroundColor: '#F5ECD5' }}> {/* Container principal com layout flex */}
        {/* Navbar lateral */}
        <Navbar />

          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/meditacao" element={<Meditacao />} />
            <Route path="/socializacao_saudavel" element={<SocializacaoSaudavel />} />
            <Route path="/rotina_sono" element={<RotinaSono />} />
            <Route path="/organizacao_financeira" element={<OrganizacaoFinanceira />} />
            <Route path="/atividades_criativas" element={<AtividadesCriativas />} />
            <Route path="/escrita_pessoal" element={<EscritaPessoal />} />
            <Route path="/exercicios_fisicos" element={<ExerciciosFisicos />} />
            <Route path="/desconexao_digital" element={<DesconexaoDigital />} />
            <Route path="/alimentacao_saudavel" element={<AlimentacaoSaudavel />} />
            <Route path="/leitura" element={<Leitura />} />
          </Routes>
          </div>
      
    </Router>
  );
}

export default App;
