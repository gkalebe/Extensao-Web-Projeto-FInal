import React from "react";
import { Link } from "react-router-dom"; // Importa o componente Link para navegação
import Navbar from './Navbar'; // Importa o componente Navbar
// Importa a imagem do botão de voltar. Ajuste o caminho './assets/'
// se a sua pasta de assets não estiver em 'src/pages/assets/'
import botaoVoltarImg from './assets/botao_voltar.webp';
import vidaULogo from './assets/VidaU_logo.png'; // Caminho ajustado
// Você pode importar uma imagem principal para esta página, se houver
// import atividadesCriativasMainImg from './assets/Atividades_criativas.png'; // Descomente e use se tiver uma imagem principal para a página

const AtividadesCriativas = () => { // Nome do componente corrigido para PascalCase
  return (
    // Fragmento React para envolver o conteúdo
    <>
    <Navbar />
    <header className="menu"> {/* class para className */}
                <div className="logo"> {/* class para className */}
                  <Link to="/"> {/* Usando Link para navegação interna */}
                    <img src={vidaULogo} alt="VidaU Logo" style={{ maxWidth: '100px' }} /> {/* Usando a variável importada */}
                  </Link>
                </div>
                
              </header>
      {/*
        As tags <div id="navbar"></div> e o <script src="navbar-loader.js"></script>
        foram removidas. Em React, o Navbar seria um componente importado e renderizado
        diretamente aqui ou em um layout pai (como o App.js).
        Por exemplo: <Navbar /> (se você tiver um componente Navbar importado).
      */}
      <main className="content-container" style={{ maxWidth: '800px', margin: '40px auto', padding: '20px', backgroundColor: '#fff', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
        <h1 style={{ textAlign: 'center', color: '#ff1493', marginBottom: '30px', fontSize: '2.5em' }}>Atividades criativas: libere seu potencial inventivo</h1>

        {/* Se houver uma imagem principal para a página, você pode adicioná-la aqui
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <img src={atividadesCriativasMainImg} alt="Atividades Criativas Ilustração" style={{ maxWidth: '100%', height: 'auto', borderRadius: '10px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' }} />
        </div>
        */}

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>1. Introdução</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            Participar de atividades que envolvem criatividade ajuda a relaxar a mente, expressar emoções e desenvolver novas habilidades. Permita-se explorar o novo e o diferente!
          </p>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>2. Benefícios das atividades criativas</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Desenvolver sua criatividade traz muitos benefícios, como:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Redução do estresse e ansiedade</li>
            <li>Melhora da capacidade de resolução de problemas</li>
            <li>Estímulo da imaginação e pensamento inovador</li>
            <li>Aumento da autoestima e autoconfiança</li>
            <li>Desenvolvimento da paciência e concentração</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>3. Dicas para incorporar a criatividade no dia a dia</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Para estimular sua criatividade:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Reserve um tempo para desenhar, pintar ou fazer artesanato</li>
            <li>Experimente escrever histórias, poesias ou diários pessoais</li>
            <li>Pratique fotografia ou explore novos ângulos no seu cotidiano</li>
            <li>Cozinhe receitas diferentes e invente pratos novos</li>
            <li>Participe de grupos ou oficinas de arte e criatividade</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>4. Atividades simples para começar</h2>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Desenhe algo que represente seu dia.</li>
            <li>Escreva uma pequena história sobre um personagem inventado por você.</li>
            <li>Faça colagens com recortes de revistas ou fotos.</li>
            <li>Experimente um novo hobby, como origami ou pintura com aquarela.</li>
          </ul>
        </section>

        <section style={{ marginBottom: '30px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>5. Motivação</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            A criatividade é um presente que você pode cultivar todos os dias. No VidaU, queremos incentivar você a explorar seu lado artístico e inovador para uma vida mais leve e cheia de significado.
          </p>
        </section>

        <div className="botao-voltar" style={{ textAlign: 'center', marginTop: '40px' }}>
          <Link to="/" className="btn-voltar" style={{
            display: 'inline-flex',
            alignItems: 'center',
            padding: '12px 25px',
            backgroundColor: '#007bff',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '5px',
            fontSize: '1.1em',
            fontWeight: 'bold',
            transition: 'background-color 0.3s ease'
          }}>
            <img src={botaoVoltarImg} alt="Voltar" style={{ width: '20px', height: '20px', marginRight: '10px' }}/>
            Voltar para Início
          </Link>
        </div>
      </main>
    </>
  );
};

export default AtividadesCriativas; // Exporta o componente com o nome corrigido
