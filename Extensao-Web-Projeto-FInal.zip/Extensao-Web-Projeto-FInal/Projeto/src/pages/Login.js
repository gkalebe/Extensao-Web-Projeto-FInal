import React, { useState } from "react"; // Importa useState para gerenciar o estado dos inputs
import { Link, useNavigate } from "react-router-dom"; // Importa Link para navegação interna e useNavigate para navegação programática

// Importa o logo da VidaU. Assumindo que o caminho é './assets/VidaU_logo.png'
// já que Login.js provavelmente está em src/pages/
import vidaULogo from './assets/VidaU_logo.png';

const Login = () => 
  {
  // Estados para os campos do formulário
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(''); // Estado para mensagens de erro
  const [loading, setLoading] = useState(false); // Estado para indicar carregamento

  const navigate = useNavigate(); // Hook para navegação programática

  // URL base do seu backend. É recomendado usar variáveis de ambiente aqui.
  const API_BASE_URL = 'http://localhost:5000'; // Ajuste conforme necessário

  // Função para lidar com o envio do formulário
  const handleSubmit = async (e) => {
    e.preventDefault(); // Previne o comportamento padrão de recarregar a página
    setError(''); // Limpa mensagens de erro anteriores
    setLoading(true); // Ativa o estado de carregamento

    try {
      const response = await fetch(`${API_BASE_URL}/api/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (!response.ok) {
        // Se a resposta não for bem-sucedida (ex: status 400, 500)
        // Lança um erro com a mensagem do backend, se houver
        throw new Error(data.error || 'Erro desconhecido no login');
      }

      // Se o login for bem-sucedido
      console.log('Login bem-sucedido!', data);
      // Aqui você normalmente armazenaria o token JWT (ex: localStorage) e o usuário
      localStorage.setItem('token', data.token);
      // Redireciona para o dashboard ou para a página inicial
      navigate('/dashboard'); 
      alert('Login realizado com sucesso!'); // Use um modal personalizado em produção
    } catch (err) {
      console.error('Erro no login:', err);
      setError(err.message || 'Falha na conexão com o servidor.');
    } finally {
      setLoading(false); // Desativa o estado de carregamento
    }
  };

  return (
    // Fragmento React para envolver o conteúdo
    <>

      <header className="menu"> {/* class para className */}
             <div className="logo"> {/* class para className */}
               <Link to="/"> {/* Usando Link para navegação interna */}
                 <img src={vidaULogo} alt="VidaU Logo" style={{ maxWidth: '100px' }} /> {/* Usando a variável importada */}
               </Link>
             </div>
             <nav className="menu-links"> {/* class para className */}
               <Link to="/Login">Entrar</Link> {/* Usando Link para navegação interna */}
               <Link to="/Register">Cadastrar</Link> {/* Usando Link para navegação interna */}
             </nav>
           </header>

      {/* Este div agora usa flex: 1 para ocupar o espaço restante e centralizar o main */}
      <div style={{
        display: 'flex',
        justifyContent: 'center', // Centraliza horizontalmente
        alignItems: 'center',     // Centraliza verticalmente
        flex: 1, // Faz este div ocupar todo o espaço flexível disponível do pai
        backgroundColor: '#F5ECD5', // Fundo para a área centralizada
        padding: '20px', // Padding para evitar que o conteúdo cole nas bordas
        boxSizing: 'border-box' // Inclui padding no cálculo total da largura/altura
      }}>
        <main className="login-container" style={{ 
          maxWidth: '450px', 
          width: '100%', // Garante que o container use a largura máxima disponível
          padding: '30px', 
          backgroundColor: '#fff', 
          borderRadius: '10px', 
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)', 
          textAlign: 'center',
          boxSizing: 'border-box' // Inclui padding e border no width/height
        }}>
          <h2 style={{ marginBottom: '25px', fontSize: '2em', color: '#333' }}>Entrar no VidaU</h2>
          <form onSubmit={handleSubmit} className="login-form" style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
            <label htmlFor="email" style={{ textAlign: 'left', fontWeight: 'bold', color: '#555' }}>E-mail:</label>
            <input 
              type="email" 
              id="email" 
              name="email" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required 
              style={{ padding: '10px', borderRadius: '5px', border: '1px solid #ddd', fontSize: '1em' }}
            />

            <label htmlFor="senha" style={{ textAlign: 'left', fontWeight: 'bold', color: '#555' }}>Senha:</label>
            <input 
              type="password" 
              id="senha" 
              name="senha" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required 
              style={{ padding: '10px', borderRadius: '5px', border: '1px solid #ddd', fontSize: '1em' }}
            />

            {error && <p style={{ color: 'red', fontSize: '0.9em', marginTop: '10px' }}>{error}</p>}

            <button 
              type="submit" 
              disabled={loading} // Desabilita o botão enquanto carrega
              style={{ 
                padding: '12px 20px', 
                backgroundColor: loading ? '#ccc' : '#007bff', 
                color: 'white', 
                border: 'none', 
                borderRadius: '5px', 
                fontSize: '1.2em', 
                fontWeight: 'bold', 
                cursor: loading ? 'not-allowed' : 'pointer', 
                marginTop: '20px',
                transition: 'background-color 0.3s ease'
              }}
            >
              {loading ? 'Entrando...' : 'Entrar'}
            </button>
          </form>
          <p className="login-link" style={{ marginTop: '20px', fontSize: '1em', color: '#555' }}>
            Não tem conta? <Link to="/register" style={{ color: '#007bff', textDecoration: 'none', fontWeight: 'bold' }}>Cadastre-se</Link>
          </p>
        </main>
      </div>
      {/* A tag <script src="script.js"></script> foi removida.
          Qualquer lógica JS que estava lá deve ser reescrita usando React hooks
          e gerenciamento de estado dentro dos componentes. */}
    </>
  );
};

export default Login;
