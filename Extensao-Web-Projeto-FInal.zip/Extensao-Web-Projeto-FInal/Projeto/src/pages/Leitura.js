import React from "react";
import { Link } from "react-router-dom"; // Importa o componente Link para navegação
import Navbar from './Navbar'; // Ajuste o caminho se necessário
// Importa a imagem do botão de voltar. Ajuste o caminho './assets/'
// se a sua pasta de assets não estiver em 'src/pages/assets/'
import botaoVoltarImg from './assets/botao_voltar.webp';
import vidaULogo from './assets/VidaU_logo.png'; // Caminho ajustado
import vivaImage from './assets/viva.png';     // Caminho ajustado

// Você pode importar uma imagem principal para esta página, se houver
// import leituraMainImg from './assets/Leitura.png'; // Descomente e use se tiver uma imagem principal para a página

const Leitura = () => { // Nome do componente corrigido para PascalCase
  return (
    
    // Fragmento React para envolver o conteúdo
    <>
    <header className="menu"> {/* class para className */}
                <div className="logo"> {/* class para className */}
                  <Link to="/"> {/* Usando Link para navegação interna */}
                    <img src={vidaULogo} alt="VidaU Logo" style={{ maxWidth: '100px' }} /> {/* Usando a variável importada */}
                  </Link>
                </div>
                
              </header>
    <Navbar /> {/* A Navbar será exibida no topo da página do Dashboard */}
      
      {/*
        As tags <div id="navbar"></div> e o <script src="navbar-loader.js"></script>
        foram removidas. Em React, o Navbar seria um componente importado e renderizado
        diretamente aqui ou em um layout pai (como o App.js).
        Por exemplo: <Navbar /> (se você tiver um componente Navbar importado).
      */}
      <main className="content-container" style={{ maxWidth: '800px', margin: '40px auto', padding: '20px', backgroundColor: '#fff', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
        <h1 style={{ textAlign: 'center', color: '#ff6600', marginBottom: '30px', fontSize: '2.5em' }}>Leitura: uma janela para novos mundos e ideias</h1>

        {/* Se houver uma imagem principal para a página, você pode adicioná-la aqui
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <img src={leituraMainImg} alt="Leitura Ilustração" style={{ maxWidth: '100%', height: 'auto', borderRadius: '10px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' }} />
        </div>
        */}

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>1. Introdução</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            A leitura é uma prática que enriquece a mente, expande o vocabulário e estimula a criatividade. Dedique alguns minutos do seu dia para mergulhar em histórias, aprender algo novo ou simplesmente relaxar.
          </p>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>2. Benefícios</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Ler regularmente traz muitos benefícios, como:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Estímulo da imaginação e criatividade</li>
            <li>Melhora da concentração e foco</li>
            <li>Ampliação do conhecimento e vocabulário</li>
            <li>Redução do estresse e relaxamento mental</li>
            <li>Desenvolvimento do pensamento crítico e empatia</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>3. Dicas para incorporar a leitura na rotina</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Para criar o hábito da leitura:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Escolha livros, artigos ou revistas que te interessem</li>
            <li>Reserve um momento tranquilo do dia, como antes de dormir</li>
            <li>Comece com leituras curtas e progressivamente aumente o tempo</li>
            <li>Use marcadores ou faça anotações para tornar a leitura mais ativa</li>
            <li>Participe de clubes de leitura ou grupos online para trocar ideias</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>4. Sugestões para leitura diária</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}><strong>Leitura leve:</strong> contos, crônicas e poesias são ótimos para começar ou relaxar.</p>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}><strong>Leitura informativa:</strong> artigos sobre saúde, ciência ou hobbies ampliam seu conhecimento.</p>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}><strong>Leitura motivacional:</strong> livros e textos que inspiram a mudança e o crescimento pessoal.</p>
        </section>

        <section style={{ marginBottom: '30px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>5. Motivação</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            Ler é um investimento em você mesmo. Cada página virada é um passo rumo a uma mente mais aberta e um coração mais sensível. No VidaU, queremos inspirar sua jornada literária!
          </p>
        </section>

        <div className="botao-voltar" style={{ textAlign: 'center', marginTop: '40px' }}>
          <Link to="/" className="btn-voltar" style={{
            display: 'inline-flex',
            alignItems: 'center',
            padding: '12px 25px',
            backgroundColor: '#007bff',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '5px',
            fontSize: '1.1em',
            fontWeight: 'bold',
            transition: 'background-color 0.3s ease'
          }}>
            <img src={botaoVoltarImg} alt="Voltar" style={{ width: '20px', height: '20px', marginRight: '10px' }}/>
            Voltar para Início
          </Link>
        </div>
      </main>
    </>
  );
};

export default Leitura; // Exporta o componente com o nome corrigido
