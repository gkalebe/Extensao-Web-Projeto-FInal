import React from "react";
import { Link } from "react-router-dom"; // Importa Link para navegação interna

const Navbar = () => {
  return (
    // Navbar principal com estilos aprimorados para um visual moderno e responsivo
    <nav className="main-navbar" style={{
      // marginLeft: 'auto', // Removido para alinhar à esquerda
      width: '220px', // Largura definida para a navbar lateral
      padding: '20px 10px', // Ajuste do padding para uma barra lateral
      backgroundColor: '#f8f8f8', // Fundo claro
      borderRadius: '8px',
      boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
      transition: 'all 0.3s ease-in-out',
      minHeight: 'calc(100vh - 40px)', // Ocupa quase toda a altura da viewport
      display: 'flex', // Permite flex-direction no nav
      flexDirection: 'column', // Alinha a própria nav na vertical
      alignItems: 'flex-start', // Alinha o conteúdo da nav à esquerda
    }}>
      <ul style={{
        listStyle: 'none',
        padding: 0,
        margin: 0,
        display: 'flex',
        flexDirection: 'column', // Itens um em cima do outro
        gap: '15px', // Espaçamento entre os itens (ajustado para vertical)
        alignItems: 'flex-start', // Alinha os itens da lista à esquerda
        width: '100%', // Para que os links ocupem a largura da nav
      }}>
        <li>
          <Link to="/dashboard" style={{
            textDecoration: 'none',
            color: '#007bff', // Cor primária
            fontSize: '1.05em',
            fontWeight: '600',
            padding: '10px 15px', // Ajustado o padding para links verticais
            borderRadius: '5px',
            transition: 'background-color 0.2s ease, color 0.2s ease',
            width: 'calc(100% - 30px)', // Para que o padding funcione dentro do width
            display: 'block', // Garante que o link ocupe toda a largura do li
          }}
          onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#e0f0ff'}
          onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
          >Dashboard</Link>
        </li>
        <li>
          <Link to="/meditacao" style={{
            textDecoration: 'none',
            color: '#007bff',
            fontSize: '1.05em',
            fontWeight: '600',
            padding: '10px 15px',
            borderRadius: '5px',
            transition: 'background-color 0.2s ease, color 0.2s ease',
            width: 'calc(100% - 30px)',
            display: 'block',
          }}
          onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#e0f0ff'}
          onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
          >Meditação</Link>
        </li>
        <li>
          <Link to="/exercicios_fisicos" style={{
            textDecoration: 'none',
            color: '#007bff',
            fontSize: '1.05em',
            fontWeight: '600',
            padding: '10px 15px',
            borderRadius: '5px',
            transition: 'background-color 0.2s ease, color 0.2s ease',
            width: 'calc(100% - 30px)',
            display: 'block',
          }}
          onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#e0f0ff'}
          onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
          >Exercícios</Link>
        </li>
        <li>
          <Link to="/leitura" style={{
            textDecoration: 'none',
            color: '#007bff',
            fontSize: '1.05em',
            fontWeight: '600',
            padding: '10px 15px',
            borderRadius: '5px',
            transition: 'background-color 0.2s ease, color 0.2s ease',
            width: 'calc(100% - 30px)',
            display: 'block',
          }}
          onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#e0f0ff'}
          onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
          >Leitura</Link>
        </li>
        <li>
          <Link to="/alimentacao_saudavel" style={{
            textDecoration: 'none',
            color: '#007bff',
            fontSize: '1.05em',
            fontWeight: '600',
            padding: '10px 15px',
            borderRadius: '5px',
            transition: 'background-color 0.2s ease, color 0.2s ease',
            width: 'calc(100% - 30px)',
            display: 'block',
          }}
          onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#e0f0ff'}
          onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
          >Alimentação</Link>
        </li>
        <li>
          <Link to="/rotina_sono" style={{
            textDecoration: 'none',
            color: '#007bff',
            fontSize: '1.05em',
            fontWeight: '600',
            padding: '10px 15px',
            borderRadius: '5px',
            transition: 'background-color 0.2s ease, color 0.2s ease',
            width: 'calc(100% - 30px)',
            display: 'block',
          }}
          onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#e0f0ff'}
          onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
          >Rotina de Sono</Link>
        </li>
        <li>
          <Link to="/desconexao_digital" style={{
            textDecoration: 'none',
            color: '#007bff',
            fontSize: '1.05em',
            fontWeight: '600',
            padding: '10px 15px',
            borderRadius: '5px',
            transition: 'background-color 0.2s ease, color 0.2s ease',
            width: 'calc(100% - 30px)',
            display: 'block',
          }}
          onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#e0f0ff'}
          onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
          >Desconexão Digital</Link>
        </li>
        <li>
          <Link to="/socializacao_saudavel" style={{
            textDecoration: 'none',
            color: '#007bff',
            fontSize: '1.05em',
            fontWeight: '600',
            padding: '10px 15px',
            borderRadius: '5px',
            transition: 'background-color 0.2s ease, color 0.2s ease',
            width: 'calc(100% - 30px)',
            display: 'block',
          }}
          onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#e0f0ff'}
          onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
          >Socialização Saudável</Link>
        </li>
        <li>
          <Link to="/organizacao_financeira" style={{
            textDecoration: 'none',
            color: '#007bff',
            fontSize: '1.05em',
            fontWeight: '600',
            padding: '10px 15px',
            borderRadius: '5px',
            transition: 'background-color 0.2s ease, color 0.2s ease',
            width: 'calc(100% - 30px)',
            display: 'block',
          }}
          onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#e0f0ff'}
          onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
          >Organização Financeira</Link>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
