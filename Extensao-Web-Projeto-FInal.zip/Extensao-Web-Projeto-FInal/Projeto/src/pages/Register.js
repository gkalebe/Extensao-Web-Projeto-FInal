import React, { useState } from "react"; // Importa useState para gerenciar o estado dos inputs
import { Link, useNavigate } from "react-router-dom"; // Importa Link para navegação e useNavigate para navegação programática

// Importa a imagem do logo. O caminho './assets/VidaU_logo.png' presume
// que Register.js está em 'src/pages/' e a pasta 'assets' em 'src/pages/assets/'.
// Se a pasta 'assets' estiver em 'src/', o caminho correto seria '../assets/VidaU_logo.png'.
import vidaULogo from "./assets/VidaU_logo.png";

const Register = () => {
  // Estados para os campos do formulário
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');     // Estado para mensagens de erro
  const [loading, setLoading] = useState(false); // Estado para indicar carregamento

  const navigate = useNavigate(); // Hook para navegação programática

  // URL base do seu backend. É recomendado usar variáveis de ambiente aqui.
  const API_BASE_URL = 'http://localhost:5000'; // Ajuste conforme necessário para o seu backend

  // Função para lidar com o envio do formulário
  const handleSubmit = async (e) => {
    e.preventDefault(); // Previne o comportamento padrão de recarregar a página
    setError('');       // Limpa mensagens de erro anteriores
    setLoading(true);   // Ativa o estado de carregamento

    try {
      // O endpoint correto para o cadastro é /api/auth/register
      const response = await fetch(`${API_BASE_URL}/api/auth/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email, password }),
      });

      const data = await response.json();

      if (!response.ok) {
        // Se a resposta não for bem-sucedida (ex: status 400, 500)
        // Lança um erro com a mensagem do backend, se houver
        throw new Error(data.error || 'Erro desconhecido no cadastro');
      }

      // Se o cadastro for bem-sucedido
      console.log('Usuário cadastrado com sucesso!', data);
      alert('Cadastro realizado com sucesso! Agora você pode fazer login.'); // Use um modal personalizado em produção
      navigate('/login'); // Redireciona para a página de login após o cadastro
    } catch (err) {
      console.error('Erro no cadastro:', err);
      setError(err.message || 'Falha na conexão com o servidor.');
    } finally {
      setLoading(false); // Desativa o estado de carregamento
    }
  };

  return (
    <> {/* Fragmento React para envolver o conteúdo sem adicionar uma div extra */}
       <header className="menu"> {/* class para className */}
              <div className="logo"> {/* class para className */}
                <Link to="/"> {/* Usando Link para navegação interna */}
                  <img src={vidaULogo} alt="VidaU Logo" style={{ maxWidth: '100px' }} /> {/* Usando a variável importada */}
                </Link>
              </div>
              <nav className="menu-links"> {/* class para className */}
                <Link to="/Login">Entrar</Link> {/* Usando Link para navegação interna */}
                <Link to="/Register">Cadastrar</Link> {/* Usando Link para navegação interna */}
              </nav>
            </header>

      {/* Este div agora usa flex: 1 para ocupar o espaço restante e centralizar o main */}
      <div style={{
        display: 'flex',
        justifyContent: 'center', // Centraliza horizontalmente
        alignItems: 'center',     // Centraliza verticalmente
        flex: 1, // Faz este div ocupar todo o espaço flexível disponível do pai
        backgroundColor: '#F5ECD5', // Fundo para a área centralizada
        padding: '20px', // Padding para evitar que o conteúdo cole nas bordas
        boxSizing: 'border-box' // Inclui padding no cálculo total da largura/altura
      }}>
        <main className="register-container" style={{
          maxWidth: '450px',
          width: '100%', // Garante que o container use a largura máxima disponível
          padding: '30px',
          backgroundColor: '#fff',
          borderRadius: '10px',
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          textAlign: 'center',
          boxSizing: 'border-box' // Inclui padding e border no width/height
        }}>
          <h2 style={{ marginBottom: '25px', fontSize: '2em', color: '#333' }}>Cadastro</h2>
          <form onSubmit={handleSubmit} className="register-form" style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
            <label htmlFor="nome" style={{ textAlign: 'left', fontWeight: 'bold', color: '#555' }}>Nome:</label>
            <input
              type="text"
              id="nome"
              name="nome"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              style={{ padding: '10px', borderRadius: '5px', border: '1px solid #ddd', fontSize: '1em' }}
            />

            <label htmlFor="email" style={{ textAlign: 'left', fontWeight: 'bold', color: '#555' }}>E-mail:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              style={{ padding: '10px', borderRadius: '5px', border: '1px solid #ddd', fontSize: '1em' }}
            />

            <label htmlFor="senha" style={{ textAlign: 'left', fontWeight: 'bold', color: '#555' }}>Senha:</label>
            <input
              type="password"
              id="senha"
              name="senha"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{ padding: '10px', borderRadius: '5px', border: '1px solid #ddd', fontSize: '1em' }}
            />

            {error && <p style={{ color: 'red', fontSize: '0.9em', marginTop: '10px' }}>{error}</p>}

            <button
              type="submit"
              disabled={loading} // Desabilita o botão enquanto carrega
              style={{
                padding: '12px 20px',
                backgroundColor: loading ? '#ccc' : '#28a745',
                color: 'white',
                border: 'none',
                borderRadius: '5px',
                fontSize: '1.2em',
                fontWeight: 'bold',
                cursor: loading ? 'not-allowed' : 'pointer',
                marginTop: '20px',
                transition: 'background-color 0.3s ease'
              }}
            >
              {loading ? 'Cadastrando...' : 'Cadastrar'}
            </button>
          </form>
          <p className="login-link" style={{ marginTop: '20px', fontSize: '1em', color: '#555' }}>
            Já tem conta? <Link to="/login" style={{ color: '#007bff', textDecoration: 'none', fontWeight: 'bold' }}>Faça login</Link>
          </p>
        </main>
      </div>
    </>
  );
};

export default Register;
