import React from "react";
import { Link } from "react-router-dom"; // Importa o componente Link para navegação interna
import Navbar from './Navbar'// Ajuste o caminho se necessário
// Importa a imagem do botão de voltar. Ajuste o caminho './assets/'
// se a sua pasta de assets não estiver em 'src/pages/assets/' (ex: '../assets/' se for em src/)
import botaoVoltarImg from './assets/botao_voltar.webp';
import vidaULogo from './assets/VidaU_logo.png'; // Caminho ajustado


// Você pode importar uma imagem principal para esta página, se houver
// import meditacaoMainImg from './assets/Meditacao.png'; // Descomente e use se tiver uma imagem principal para a página

const Meditacao = () => { // Nome do componente já está corrigido para PascalCase
  return (
    // Fragmento React para envolver o conteúdo sem adicionar uma div extra
    <>
    <Navbar /> {/* A Navbar será exibida no topo da página do Dashboard */}
    <header className="menu"> {/* class para className */}
                <div className="logo"> {/* class para className */}
                  <Link to="/"> {/* Usando Link para navegação interna */}
                    <img src={vidaULogo} alt="VidaU Logo" style={{ maxWidth: '100px' }} /> {/* Usando a variável importada */}
                  </Link>
                </div>
                
              </header>
      <main>
        {/* Conteúdo do Dashboard */}
        <h1></h1>
        {/* ... */}
      </main>
      {/*
        As tags <div id="navbar"></div> e <script src="navbar-loader.js"></script>
        foram removidas. Em React, o Navbar seria um componente importado e renderizado
        diretamente aqui ou em um layout pai (como o App.js).
        Por exemplo: <Navbar /> (se você tiver um componente Navbar importado).
      */}
      <main className="content-container" style={{ maxWidth: '800px', margin: '40px auto', padding: '20px', backgroundColor: '#fff', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
        <h1 style={{ textAlign: 'center', color: '#28a745', marginBottom: '30px', fontSize: '2.5em' }}>Meditação: o caminho para o equilíbrio interior</h1>

        {/* Se houver uma imagem principal para a página, você pode adicioná-la aqui
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <img src={meditacaoMainImg} alt="Meditação Ilustração" style={{ maxWidth: '100%', height: 'auto', borderRadius: '10px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' }} />
        </div>
        */}

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>1. Introdução</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            Praticar a meditação diariamente ajuda a acalmar a mente, reduzir o estresse e aumentar a concentração. É um momento só seu, para reconectar corpo e mente.
          </p>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>2. Benefícios</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>A meditação traz diversos benefícios para o corpo e a mente, entre eles:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Redução da ansiedade e do estresse</li>
            <li>Melhora da qualidade do sono</li>
            <li>Aumento da atenção e foco</li>
            <li>Fortalecimento da inteligência emocional</li>
            <li>Maior sensação de paz e bem-estar</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>3. Dicas para começar</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Se você está começando agora, experimente:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Escolher um local tranquilo e confortável</li>
            <li>Sentar-se com a coluna ereta e os olhos fechados</li>
            <li>Focar na respiração, inspirando e expirando lentamente</li>
            <li>Não se preocupar com distrações, apenas retorne sua atenção à respiração</li>
            <li>Começar com sessões curtas, de 5 a 10 minutos, e ir aumentando aos poucos</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>4. Exercícios simples</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}><strong>Exercício de respiração consciente:</strong></p>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Inspire profundamente pelo nariz contando até 4, segure a respiração por 4 segundos, expire lentamente pela boca contando até 6. Repita por 5 minutos para acalmar a mente.</p>
        </section>

        <section style={{ marginBottom: '30px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>5. Motivação</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            A prática constante transforma. Reserve alguns minutos do seu dia para cuidar da sua mente. No VidaU, estamos juntos nessa jornada rumo a uma vida mais saudável e equilibrada.
          </p>
        </section>

        <div className="botao-voltar" style={{ textAlign: 'center', marginTop: '40px' }}>
          <Link to="/" className="btn-voltar" style={{
            display: 'inline-flex',
            alignItems: 'center',
            padding: '12px 25px',
            backgroundColor: '#007bff',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '5px',
            fontSize: '1.1em',
            fontWeight: 'bold',
            transition: 'background-color 0.3s ease'
          }}>
            <img src={botaoVoltarImg} alt="Voltar" style={{ width: '20px', height: '20px', marginRight: '10px' }}/>
            Voltar para Início
          </Link>
        </div>
      </main>
    </>
  );
};

export default Meditacao; // Exporta o componente com o nome corrigido
