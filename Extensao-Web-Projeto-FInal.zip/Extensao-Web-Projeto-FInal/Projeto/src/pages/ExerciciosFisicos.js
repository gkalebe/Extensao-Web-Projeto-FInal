import React from "react";
import { Link } from "react-router-dom"; // Importa o componente Link para navegação
import Navbar from "./Navbar";
// Importa a imagem do botão de voltar. Ajuste o caminho './assets/'
// se a sua pasta de assets não estiver em 'src/pages/assets/'
import botaoVoltarImg from './assets/botao_voltar.webp';
import vidaULogo from './assets/VidaU_logo.png'; // Caminho ajustado


// Você pode importar uma imagem principal para esta página, se houver
// import exerciciosFisicosMainImg from './assets/Exercicios_fisicos.png';


const ExerciciosFisicos = () => { // Nome do componente corrigido para PascalCase
  return (
    
    // Fragmento React para envolver o conteúdo
    <>
    <header className="menu"> {/* class para className */}
                <div className="logo"> {/* class para className */}
                  <Link to="/"> {/* Usando Link para navegação interna */}
                    <img src={vidaULogo} alt="VidaU Logo" style={{ maxWidth: '100px' }} /> {/* Usando a variável importada */}
                  </Link>
                </div>
                
              </header>
    <Navbar />
      {/*
        As tags <div id="navbar"></div> e <script src="navbar-loader.js"></script>
        foram removidas. Em React, o Navbar seria um componente importado e renderizado
        diretamente aqui ou em um layout pai (como o App.js).
        Por exemplo: <Navbar /> (se você tiver um componente Navbar).
      */}
      <main className="content-container" style={{ maxWidth: '800px', margin: '40px auto', padding: '20px', backgroundColor: '#fff', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
        <h1 style={{ textAlign: 'center', color: '#6a0dad', marginBottom: '30px', fontSize: '2.5em' }}>Movimente seu corpo, fortaleça sua vida</h1>

        {/* Se houver uma imagem principal para a página, você pode adicioná-la aqui
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <img src={exerciciosFisicosMainImg} alt="Exercícios Físicos Ilustração" style={{ maxWidth: '100%', height: 'auto', borderRadius: '10px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' }} />
        </div>
        */}

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>1. Introdução</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            A prática regular de exercícios físicos é essencial para manter a saúde, aumentar a energia e melhorar o humor. Comece hoje mesmo e sinta a diferença no seu dia a dia.
          </p>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>2. Benefícios</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Os exercícios trazem inúmeros benefícios para o corpo e a mente, como:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Melhora da capacidade cardiovascular e pulmonar</li>
            <li>Fortalecimento muscular e ósseo</li>
            <li>Controle do peso corporal</li>
            <li>Redução do estresse e ansiedade</li>
            <li>Melhora do sono e da disposição</li>
            <li>Aumento da autoestima e confiança</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>3. Dicas para começar</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Para iniciar sua rotina de exercícios:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Escolha atividades que você goste, como caminhada, dança, yoga ou musculação</li>
            <li>Comece devagar, respeitando seus limites</li>
            <li>Estabeleça metas realistas e progressivas</li>
            <li>Utilize roupas confortáveis e beba bastante água</li>
            <li>Ouça seu corpo e descanse quando necessário</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>4. Exercícios simples para o dia a dia</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}><strong>Alongamento matinal:</strong></p>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Alongue braços, pernas e pescoço por alguns minutos para preparar o corpo para o dia.</p>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}><strong>Caminhada rápida:</strong></p>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Caminhe por 20 a 30 minutos em ritmo acelerado para ativar o coração e queimar calorias.</p>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}><strong>Exercícios de força:</strong></p>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Agachamentos, flexões e abdominais ajudam a fortalecer músculos sem necessidade de equipamentos.</p>
        </section>

        <section style={{ marginBottom: '30px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>5. Motivação</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            Não importa onde você esteja, o importante é dar o primeiro passo. Pequenas mudanças diárias criam grandes resultados ao longo do tempo. No VidaU, vamos te apoiar para manter-se ativo e saudável!
          </p>
        </section>

        <div className="botao-voltar" style={{ textAlign: 'center', marginTop: '40px' }}>
          <Link to="/" className="btn-voltar" style={{
            display: 'inline-flex',
            alignItems: 'center',
            padding: '12px 25px',
            backgroundColor: '#007bff',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '5px',
            fontSize: '1.1em',
            fontWeight: 'bold',
            transition: 'background-color 0.3s ease'
          }}>
            <img src={botaoVoltarImg} alt="Voltar" style={{ width: '20px', height: '20px', marginRight: '10px' }}/>
            Voltar para Início
          </Link>
        </div>
      </main>
    </>
  );
};

export default ExerciciosFisicos; // Exporta o componente com o nome corrigido
