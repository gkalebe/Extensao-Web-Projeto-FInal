import React from "react";
import { Link } from "react-router-dom"; // Importa o componente Link para navegação
import Navbar from './Navbar' // Importa o componente Navbar
// Importa a imagem do botão de voltar. Ajuste o caminho './assets/'
// se a sua pasta de assets não estiver em 'src/pages/assets/'
import botaoVoltarImg from './assets/botao_voltar.webp';
import vidaULogo from './assets/VidaU_logo.png'; // Caminho ajustado

// Você pode importar uma imagem principal para esta página, se houver
// import alimentacaoSaudavelMainImg from './assets/Alimentacao_saudavel.png'; // Uncomment and use if there's a main image for the page

const AlimentacaoSaudavel = () => { // Component name corrected to PascalCase
  return (
    // React Fragment to wrap the content
    <>
    <Navbar />
    <header className="menu"> {/* class para className */}
            <div className="logo"> {/* class para className */}
              <Link to="/"> {/* Usando Link para navegação interna */}
                <img src={vidaULogo} alt="VidaU Logo" style={{ maxWidth: '100px' }} /> {/* Usando a variável importada */}
              </Link>
            </div>
            
          </header>
      {/*
        The <body> tag, <div id="navbar"></div>, and <script src="navbar-loader.js"></script>
        have been removed. In React, the Navbar would be an imported and rendered component
        directly here or in a parent layout (like App.js).
        For example: <Navbar /> (if you have a Navbar component imported).
      */}
      <main className="content-container" style={{ maxWidth: '800px', margin: '40px auto', padding: '20px', backgroundColor: '#fff', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
        <h1 style={{ textAlign: 'center', color: '#20c997', marginBottom: '30px', fontSize: '2.5em' }}>Alimentação saudável: o combustível para o seu corpo</h1>

        {/* If there's a main image for the page, you can add it here
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <img src={alimentacaoSaudavelMainImg} alt="Alimentação Saudável Ilustração" style={{ maxWidth: '100%', height: 'auto', borderRadius: '10px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' }} />
        </div>
        */}

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>1. Introdução</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            Uma alimentação equilibrada é fundamental para garantir energia, disposição e saúde a longo prazo. Comer bem é um ato de cuidado consigo mesmo.
          </p>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>2. Benefícios</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Manter uma alimentação saudável traz inúmeros benefícios:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Melhora do sistema imunológico</li>
            <li>Controle do peso corporal</li>
            <li>Redução do risco de doenças crônicas como diabetes e hipertensão</li>
            <li>Melhora da digestão e funcionamento do organismo</li>
            <li>Aumento da disposição e do bem-estar geral</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>3. Dicas para uma alimentação equilibrada</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Para começar a comer melhor:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Inclua frutas, verduras e legumes variados no seu dia a dia</li>
            <li>Prefira alimentos integrais e naturais em vez de processados</li>
            <li>Beba bastante água ao longo do dia</li>
            <li>Evite o consumo excessivo de açúcar, sal e gorduras saturadas</li>
            <li>Faça refeições regulares e evite pular o café da manhã</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>4. Práticas simples para o dia a dia</h2>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Planeje suas refeições: organize o cardápio semanal para evitar escolhas impulsivas.</li>
            <li>Cozinhe em casa: assim você controla melhor os ingredientes usados.</li>
            <li>Lanches saudáveis: troque salgadinhos por castanhas, frutas ou iogurte natural.</li>
            <li>Coma com atenção: aproveite o momento da refeição sem distrações, mastigando devagar.</li>
          </ul>
        </section>

        <section style={{ marginBottom: '30px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>5. Motivação</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            Pequenas mudanças alimentares fazem grande diferença na sua qualidade de vida. No VidaU, queremos te ajudar a construir hábitos saudáveis que durem para sempre!
          </p>
        </section>

        <div className="botao-voltar" style={{ textAlign: 'center', marginTop: '40px' }}>
          <Link to="/" className="btn-voltar" style={{
            display: 'inline-flex',
            alignItems: 'center',
            padding: '12px 25px',
            backgroundColor: '#007bff',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '5px',
            fontSize: '1.1em',
            fontWeight: 'bold',
            transition: 'background-color 0.3s ease'
          }}>
            <img src={botaoVoltarImg} alt="Voltar" style={{ width: '20px', height: '20px', marginRight: '10px' }}/>
            Voltar para Início
          </Link>
        </div>
      </main>
    </>
  );
};

export default AlimentacaoSaudavel; // Export the component with the corrected name
