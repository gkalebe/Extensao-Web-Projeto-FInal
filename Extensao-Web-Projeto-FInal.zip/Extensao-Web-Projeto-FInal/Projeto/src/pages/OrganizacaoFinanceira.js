import React from "react";
import { Link } from "react-router-dom"; // Importa o componente Link para navegação
import Navbar from './Navbar'; // Importa o componente Navbar
// Importa a imagem do botão de voltar. Ajuste o caminho './assets/'
// se a sua pasta de assets não estiver em 'src/pages/assets/'
import botaoVoltarImg from './assets/botao_voltar.webp';
import vidaULogo from './assets/VidaU_logo.png'; // Caminho ajustado
import vivaImage from './assets/viva.png';     // Caminho ajustado

// Importa a imagem específica desta página (se houver uma imagem principal para a página)
// import organizacaoFinanceiraImg from './assets/Organizacao_financeira.png'; // Descomente e use se tiver uma imagem principal para a página


const OrganizacaoFinanceira = () => { // Nome do componente corrigido para PascalCase
  return (
    // Fragmento React para envolver o conteúdo
    <>
    <Navbar />
    <header className="menu"> {/* class para className */}
            <div className="logo"> {/* class para className */}
              <Link to="/"> {/* Usando Link para navegação interna */}
                <img src={vidaULogo} alt="VidaU Logo" style={{ maxWidth: '100px' }} /> {/* Usando a variável importada */}
              </Link>
            </div>
            <nav className="menu-links"> {/* class para className */}
              <Link to="/Login">Entrar</Link> {/* Usando Link para navegação interna */}
              <Link to="/Register">Cadastrar</Link> {/* Usando Link para navegação interna */}
            </nav>
          </header>
      {/*
        A tag <div id="navbar"></div> e o <script src="navbar-loader.js"></script>
        foram removidos. Em React, o Navbar seria um componente importado e renderizado
        diretamente aqui ou em um layout pai (como o App.js).
        Por exemplo: <Navbar /> (se você tiver um componente Navbar).
      */}
      <main className="content-container" style={{ maxWidth: '800px', margin: '40px auto', padding: '20px', backgroundColor: '#fff', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
        <h1 style={{ textAlign: 'center', color: '#ffc107', marginBottom: '30px', fontSize: '2.5em' }}>Organização financeira: controle que traz liberdade</h1>

        {/* Se houver uma imagem principal para a página, você pode adicioná-la aqui
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <img src={organizacaoFinanceiraImg} alt="Organização Financeira Ilustração" style={{ maxWidth: '100%', height: 'auto', borderRadius: '10px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' }} />
        </div>
        */}

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>1. Introdução</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            Manter suas finanças organizadas é essencial para alcançar seus objetivos, evitar dívidas e garantir tranquilidade no dia a dia.
          </p>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>2. Benefícios da organização financeira</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Uma boa gestão financeira proporciona:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Redução do estresse relacionado ao dinheiro</li>
            <li>Planejamento para imprevistos e sonhos futuros</li>
            <li>Controle dos gastos e melhor uso da renda</li>
            <li>Construção de uma reserva de emergência</li>
            <li>Melhora da qualidade de vida e segurança financeira</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>3. Dicas para organizar suas finanças</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Para começar a se organizar financeiramente:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Anote todas as suas despesas e receitas diariamente</li>
            <li>Crie um orçamento mensal com limites para cada categoria</li>
            <li>Evite compras por impulso e reveja seus hábitos de consumo</li>
            <li>Poupe uma parte da sua renda, mesmo que pequena, regularmente</li>
            <li>Use aplicativos ou planilhas para acompanhar suas finanças</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>4. Práticas para manter o controle financeiro</h2>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Revise suas contas mensalmente: acompanhe o que entrou e saiu.</li>
            <li>Estabeleça metas financeiras: para viagens, estudos ou investimentos.</li>
            <li>Negocie dívidas: procure alternativas para diminuir juros e parcelas.</li>
            <li>Eduque-se financeiramente: leia livros, assista vídeos e participe de cursos.</li>
          </ul>
        </section>

        <section style={{ marginBottom: '30px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>5. Motivação</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            Organização financeira é um passo importante para uma vida mais segura e livre de preocupações. No VidaU, incentivamos você a construir e manter hábitos financeiros saudáveis e duradouros.
          </p>
        </section>

        <div className="botao-voltar" style={{ textAlign: 'center', marginTop: '40px' }}>
          <Link to="/" className="btn-voltar" style={{
            display: 'inline-flex',
            alignItems: 'center',
            padding: '12px 25px',
            backgroundColor: '#007bff',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '5px',
            fontSize: '1.1em',
            fontWeight: 'bold',
            transition: 'background-color 0.3s ease'
          }}>
            <img src={botaoVoltarImg} alt="Voltar" style={{ width: '20px', height: '20px', marginRight: '10px' }}/>
            Voltar para Início
          </Link>
        </div>
      </main>
    </>
  );
};

export default OrganizacaoFinanceira; // Exporta o componente com o nome corrigido
