import React from "react";
import { Link } from "react-router-dom"; // Importa o componente Link para navegação
import Navbar from './Navbar'; // Importa o componente Navbar
// Importa a imagem do botão de voltar. Ajuste o caminho './assets/'
// se a sua pasta de assets não estiver em 'src/pages/assets/'
import botaoVoltarImg from './assets/botao_voltar.webp';
import vidaULogo from './assets/VidaU_logo.png'; // Caminho ajustado


// Você pode importar uma imagem principal para esta página, se houver
// import desconexaoDigitalMainImg from './assets/Desconexao_digital.png'; // Descomente e use se tiver uma imagem principal para a página

const DesconexaoDigital = () => { // Nome do componente corrigido para PascalCase
  return (
    // Fragmento React para envolver o conteúdo
    <>
    <header className="menu"> {/* class para className */}
                <div className="logo"> {/* class para className */}
                  <Link to="/"> {/* Usando Link para navegação interna */}
                    <img src={vidaULogo} alt="VidaU Logo" style={{ maxWidth: '100px' }} /> {/* Usando a variável importada */}
                  </Link>
                </div>
                
              </header>
     <Navbar />
     <header className="menu"> {/* class para className */}
             <div className="logo"> {/* class para className */}
               <Link to="/"> {/* Usando Link para navegação interna */}
                 <img src={vidaULogo} alt="VidaU Logo" style={{ maxWidth: '100px' }} /> {/* Usando a variável importada */}
               </Link>
             </div>
             <nav className="menu-links"> {/* class para className */}
               <Link to="/Login">Entrar</Link> {/* Usando Link para navegação interna */}
               <Link to="/Register">Cadastrar</Link> {/* Usando Link para navegação interna */}
             </nav>
           </header>
     
      {/*
        As tags <div id="navbar"></div> e o <script src="navbar-loader.js"></script>
        foram removidas. Em React, o Navbar seria um componente importado e renderizado
        diretamente aqui ou em um layout pai (como o App.js).
        Por exemplo: <Navbar /> (se você tiver um componente Navbar importado).
      */}
      <main className="content-container" style={{ maxWidth: '800px', margin: '40px auto', padding: '20px', backgroundColor: '#fff', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
        <h1 style={{ textAlign: 'center', color: '#663399', marginBottom: '30px', fontSize: '2.5em' }}>Desconexão digital: reconecte-se com o mundo real</h1>

        {/* Se houver uma imagem principal para a página, você pode adicioná-la aqui
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <img src={desconexaoDigitalMainImg} alt="Desconexão Digital Ilustração" style={{ maxWidth: '100%', height: 'auto', borderRadius: '10px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' }} />
        </div>
        */}

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>1. Introdução</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            Em um mundo cada vez mais conectado, reservar momentos para se desligar das telas é fundamental para o equilíbrio mental, a produtividade e o bem-estar.
          </p>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>2. Benefícios da desconexão digital</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Tirar pausas das redes sociais, emails e dispositivos eletrônicos traz muitos benefícios, como:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Redução do estresse e ansiedade</li>
            <li>Melhora da qualidade do sono</li>
            <li>Aumento da concentração e foco nas tarefas</li>
            <li>Fortalecimento das relações interpessoais presenciais</li>
            <li>Mais tempo para atividades criativas e relaxantes</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>3. Dicas para praticar a desconexão</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Para desconectar de forma saudável:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Defina horários específicos para checar seu celular e redes sociais</li>
            <li>Utilize modos “não perturbe” ou apps que bloqueiam notificações temporariamente</li>
            <li>Reserve momentos sem telas para caminhar, ler ou conversar pessoalmente</li>
            <li>Estabeleça uma rotina de desligar aparelhos pelo menos 1 hora antes de dormir</li>
            <li>Experimente um “detox digital” nos finais de semana</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>4. Atividades para substituir o tempo de tela</h2>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Caminhada ao ar livre: aproveite a natureza e respire ar fresco.</li>
            <li>Meditação ou exercícios de respiração: acalme a mente e o corpo.</li>
            <li>Leitura de livros ou revistas: estimule a criatividade e o conhecimento.</li>
            <li>Atividades manuais: pintura, escrita, jardinagem ou artesanato ajudam a relaxar.</li>
          </ul>
        </section>

        <section style={{ marginBottom: '30px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>5. Motivação</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            Equilibrar o mundo digital com momentos offline é um ato de cuidado com a sua saúde mental. No VidaU, te apoiamos a encontrar esse equilíbrio essencial para uma vida plena e saudável.
          </p>
        </section>

        <div className="botao-voltar" style={{ textAlign: 'center', marginTop: '40px' }}>
          <Link to="/" className="btn-voltar" style={{
            display: 'inline-flex',
            alignItems: 'center',
            padding: '12px 25px',
            backgroundColor: '#007bff',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '5px',
            fontSize: '1.1em',
            fontWeight: 'bold',
            transition: 'background-color 0.3s ease'
          }}>
            <img src={botaoVoltarImg} alt="Voltar" style={{ width: '20px', height: '20px', marginRight: '10px' }}/>
            Voltar para Início
          </Link>
        </div>
      </main>
    </>
  );
};

export default DesconexaoDigital; // Exporta o componente com o nome corrigido
