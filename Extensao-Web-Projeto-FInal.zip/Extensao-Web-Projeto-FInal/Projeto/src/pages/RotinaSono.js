import React from "react";
import { Link } from "react-router-dom"; // Importa o componente Link para navegação
import Navbar from './Navbar'; // Importa o componente Navbar
// Importa a imagem do botão de voltar. Ajuste o caminho './assets/'
// se a sua pasta de assets não estiver em 'src/pages/assets/'
import botaoVoltarImg from './assets/botao_voltar.webp';
import vidaULogo from './assets/VidaU_logo.png'; // Caminho ajustado
import vivaImage from './assets/viva.png';     // Caminho ajustado

// Você pode importar uma imagem principal para esta página, se houver
// import rotinaSonoMainImg from './assets/Rotina_de_sono.png';


const RotinaSono = () => { // Nome do componente corrigido para PascalCase
  return (
    // Fragmento React para envolver o conteúdo
    <>
    <Navbar />
      {/*
        As tags <div id="navbar"></div> e <script src="navbar-loader.js"></script>
        foram removidas. Em React, o Navbar seria um componente importado e renderizado
        diretamente aqui ou em um layout pai (como o App.js).
        Por exemplo: <Navbar /> (se você tiver um componente Navbar).
      */}
      <main className="content-container" style={{ maxWidth: '800px', margin: '40px auto', padding: '20px', backgroundColor: '#fff', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
        <h1 style={{ textAlign: 'center', color: '#8a2be2', marginBottom: '30px', fontSize: '2.5em' }}>Rotina de sono: o descanso que seu corpo e mente precisam</h1>

        {/* Se houver uma imagem principal para a página, você pode adicioná-la aqui
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <img src={rotinaSonoMainImg} alt="Rotina de Sono Ilustração" style={{ maxWidth: '100%', height: 'auto', borderRadius: '10px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' }} />
        </div>
        */}

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>1. Introdução</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            Ter uma rotina regular de sono é essencial para recuperar as energias, melhorar a concentração e fortalecer o sistema imunológico. Dormir bem é cuidar da sua saúde integral.
          </p>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>2. Benefícios de um sono regular</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Uma boa rotina de sono traz diversos benefícios, como:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Melhora da memória e do aprendizado</li>
            <li>Regulação do humor e redução do estresse</li>
            <li>Reforço do sistema imunológico</li>
            <li>Recuperação física e mental durante a noite</li>
            <li>Melhora da produtividade e energia durante o dia</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>3. Dicas para uma rotina de sono saudável</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Para melhorar seu sono:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Estabeleça horários fixos para dormir e acordar, inclusive nos fins de semana</li>
            <li>Crie um ambiente tranquilo, escuro e confortável no quarto</li>
            <li>Evite telas e luzes fortes pelo menos 1 hora antes de dormir</li>
            <li>Evite cafeína e refeições pesadas à noite</li>
            <li>Pratique atividades relaxantes, como leitura leve ou meditação antes de dormir</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>4. Práticas para um sono reparador</h2>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Desconecte-se: desligue eletrônicos para reduzir a estimulação mental.</li>
            <li>Respiração profunda: pratique exercícios de respiração para relaxar o corpo.</li>
            <li>Evite cochilos longos: se precisar, durma no máximo 20 minutos para não atrapalhar o sono noturno.</li>
          </ul>
        </section>

        <section style={{ marginBottom: '30px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>5. Motivação</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            Valorize o seu sono como um momento de cuidado e renovação. No VidaU, queremos te ajudar a criar hábitos que garantam noites tranquilas e dias cheios de disposição.
          </p>
        </section>

        <div className="botao-voltar" style={{ textAlign: 'center', marginTop: '40px' }}>
          <Link to="/" className="btn-voltar" style={{
            display: 'inline-flex',
            alignItems: 'center',
            padding: '12px 25px',
            backgroundColor: '#007bff',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '5px',
            fontSize: '1.1em',
            fontWeight: 'bold',
            transition: 'background-color 0.3s ease'
          }}>
            <img src={botaoVoltarImg} alt="Voltar" style={{ width: '20px', height: '20px', marginRight: '10px' }}/>
            Voltar para Início
          </Link>
        </div>
      </main>
    </>
  );
};

export default RotinaSono; // Exporta o componente com o nome corrigido
