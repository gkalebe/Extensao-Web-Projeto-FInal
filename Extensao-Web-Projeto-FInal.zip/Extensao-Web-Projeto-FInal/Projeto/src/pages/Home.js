import React from "react";
import { Link } from "react-router-dom"; // Importa o componente Link para navegação interna

// Importa as imagens. O caminho é ajustado para './assets/'
// pois as imagens parecem estar em 'src/pages/assets/' e Home.js está em 'src/pages/'
import vidaULogo from './assets/VidaU_logo.png'; // Caminho ajustado
import vivaImage from './assets/viva.png';     // Caminho ajustado
import CarrosselDeCategorias from './CarrosselDeCategorias'; // Importa o componente CarrosselDeCategorias

const Home = () => {
  return (
    <> {/* Fragmento React para envolver o conteúdo sem adicionar uma div extra */}
      <header className="menu"> {/* class para className */}
        <div className="logo"> {/* class para className */}
          <Link to="/"> {/* Usando Link para navegação interna */}
            <img src={vidaULogo} alt="VidaU Logo" style={{ maxWidth: '100px' }} /> {/* Usando a variável importada */}
          </Link>
        </div>
        <nav className="menu-links"> {/* class para className */}
          <Link to="/Login">Entrar</Link> {/* Usando Link para navegação interna */}
          <Link to="/Register">Cadastrar</Link> {/* Usando Link para navegação interna */}
        </nav>
      </header>

      <section className="intro"> {/* class para className */}
        <div className="intro-texto"> {/* class para className */}
          <h1>🌱 Bem-vindo(a) ao VidaU!</h1>
          <p>
            Sua jornada rumo a hábitos mais saudáveis começa aqui. O VidaU foi pensado para ser seu aliado diário na criação, no acompanhamento e na manutenção de metas que promovem bem-estar e saúde mental.
          </p>
          <p>
            📌 <strong>O que você encontra na plataforma?</strong><br />
            Metas personalizadas: registre atividades como meditação, exercícios físicos, leitura e muito mais.<br />
            Painel de progresso: visualize conquistas diárias e mensais de forma clara e motivadora.<br />
            Tecnologia acessível: interface simples, responsiva e pronta para ser usada em qualquer dispositivo.<br />
            Nosso objetivo é tornar o cuidado consigo mesmo algo prático, agradável e possível para todos. Comece agora e descubra como pequenos passos diários podem transformar a sua rotina!
          </p>
        </div>
        <div className="intro-imagem"> {/* class para className */}
          <img src={vivaImage} alt="Vida saudável" style={{ maxWidth: '400px' }} /> {/* Usando a variável importada */}
        </div>
      </section>

      <section className="carrossel" style={{ padding: '40px 20px', backgroundColor: '#F5ECD5', textAlign: 'center' }}>
        <h2 style={{ marginBottom: '30px', fontSize: '2em', color: '#333' }}>Categorias de hábitos</h2>
        {/* Renderiza o componente CarrosselDeCategorias aqui */}
        <CarrosselDeCategorias />
      </section>
    </>
  );
};

export default Home;
