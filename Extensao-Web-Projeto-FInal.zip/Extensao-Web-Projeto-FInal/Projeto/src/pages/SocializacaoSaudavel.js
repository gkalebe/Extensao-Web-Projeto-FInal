import React from "react";
import { Link } from "react-router-dom"; // Importa o componente Link para navegação
import Navbar from './Navbar'; // Importa o componente Navbar
// Importa a imagem do botão de voltar. Ajuste o caminho './assets/'
// se a sua pasta de assets não estiver em 'src/pages/assets/'
import botaoVoltarImg from './assets/botao_voltar.webp';
import vidaULogo from './assets/VidaU_logo.png'; // Caminho ajustado
import vivaImage from './assets/viva.png';     // Caminho ajustado

// Importa a imagem específica desta página (se houver uma imagem principal para a página)
// import socializacaoSaudavelImg from './assets/Socializacao_saudavel.png'; // Descomente e use se tiver uma imagem principal para a página


const SocializacaoSaudavel = () => { // Nome do componente corrigido para PascalCase
  return (
    // Fragmento React para envolver o conteúdo
    <>
    <Navbar />
      {/*
        A tag <div id="navbar"></div> e o <script src="navbar-loader.js"></script>
        foram removidos. Em React, o Navbar seria um componente importado e renderizado
        diretamente aqui ou em um layout pai (como o App.js).
        Por exemplo: <Navbar /> (se você tiver um componente Navbar).
      */}
      <main className="content-container" style={{ maxWidth: '800px', margin: '40px auto', padding: '20px', backgroundColor: '#fff', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
        <h1 style={{ textAlign: 'center', color: '#20c997', marginBottom: '30px', fontSize: '2.5em' }}>Socialização saudável: conexões que fortalecem</h1>

        {/* Se houver uma imagem principal para a página, você pode adicioná-la aqui
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <img src={socializacaoSaudavelImg} alt="Socialização Saudável Ilustração" style={{ maxWidth: '100%', height: 'auto', borderRadius: '10px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' }} />
        </div>
        */}

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>1. Introdução</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            Ter relações sociais positivas é fundamental para o bem-estar emocional, ajudando a construir apoio, confiança e felicidade no dia a dia.
          </p>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>2. Benefícios da socialização saudável</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Cultivar boas relações traz muitos benefícios, como:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Redução do estresse e sensação de solidão</li>
            <li>Melhora da autoestima e confiança</li>
            <li>Apoio emocional em momentos difíceis</li>
            <li>Estímulo ao crescimento pessoal e aprendizado</li>
            <li>Aumento da sensação de pertencimento e segurança</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>3. Dicas para fortalecer suas relações</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Para manter uma socialização saudável:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Dedique tempo para ouvir e compreender os outros</li>
            <li>Participe de atividades em grupo que você goste</li>
            <li>Seja sincero e transparente em suas conversas</li>
            <li>Estabeleça limites saudáveis e respeite os dos outros</li>
            <li>Invista em relacionamentos que trazem apoio e positividade</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>4. Atividades para socializar</h2>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Encontros presenciais: jantares, cafés ou passeios com amigos e família.</li>
            <li>Grupos de interesse: participe de clubes, oficinas ou eventos relacionados aos seus hobbies.</li>
            <li>Voluntariado: ajudar outras pessoas cria conexões significativas.</li>
            <li>Atividades online: participe de fóruns e comunidades virtuais que compartilhem seus interesses.</li>
          </ul>
        </section>

        <section style={{ marginBottom: '30px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>5. Motivação</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            Relacionamentos saudáveis são pilares para uma vida feliz e equilibrada. No VidaU, incentivamos você a construir e manter conexões que elevem seu bem-estar.
          </p>
        </section>

        <div className="botao-voltar" style={{ textAlign: 'center', marginTop: '40px' }}>
          <Link to="/" className="btn-voltar" style={{
            display: 'inline-flex',
            alignItems: 'center',
            padding: '12px 25px',
            backgroundColor: '#007bff',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '5px',
            fontSize: '1.1em',
            fontWeight: 'bold',
            transition: 'background-color 0.3s ease'
          }}>
            <img src={botaoVoltarImg} alt="Voltar" style={{ width: '20px', height: '20px', marginRight: '10px' }}/>
            Voltar para Início
          </Link>
        </div>
      </main>
    </>
  );
};

export default SocializacaoSaudavel; // Exporta o componente com o nome corrigido
