import React from "react";
import { Link } from "react-router-dom"; // Importa o componente Link para navegação interna

// Importa todas as imagens das categorias de hábitos.
// Ajuste o caminho './assets/' se a sua pasta de imagens estiver em outro lugar
// em relação a onde este componente será salvo (ex: se este componente for salvo em src/components/,
// e as imagens em src/assets/, o caminho seria '../../assets/').
import meditacaoImg from './assets/Meditacao.png';
import exerciciosFisicosImg from './assets/Exercicios_fisicos.png';
import leituraImg from './assets/Leitura.png';
import alimentacaoSaudavelImg from './assets/Alimentacao_saudavel.png';
import rotinaSonoImg from './assets/Rotina_de_sono.png';
import desconexaoDigitalImg from './assets/Desconexao_digital.png';
import escritaPessoalImg from './assets/Escrita_pessoal.png';
import atividadesCriativasImg from './assets/Atividades_criativas.png';
import socializacaoSaudavelImg from './assets/Socializacao_saudavel.png';
import organizacaoFinanceiraImg from './assets/Organizacao_financeira.png';

const CarrosselDeCategorias = () => {
  // O array de categorias, agora usando as variáveis de imagem importadas
  // e as rotas internas do React Router (prefixadas com '/')
  const categorias = [
    { nome: "Meditação", imagem: meditacaoImg, route: "/meditacao" }, // Corrigido para string de rota
    { nome: "Exercícios físicos", imagem: exerciciosFisicosImg, route: "/exercicios_fisicos" }, // Corrigido para string de rota
    { nome: "Leitura", imagem: leituraImg, route: "/leitura" }, // Corrigido para string de rota
    { nome: "Alimentação saudável", imagem: alimentacaoSaudavelImg, route: "/alimentacao_saudavel" }, // Corrigido para string de rota
    { nome: "Rotina de sono", imagem: rotinaSonoImg, route: "/rotina_sono" }, // Corrigido para string de rota
    { nome: "Desconexão digital", imagem: desconexaoDigitalImg, route: "/desconexao_digital" }, // Corrigido para string de rota
    { nome: "Escrita pessoal", imagem: escritaPessoalImg, route: "/escrita_pessoal" }, // Corrigido para string de rota
    { nome: "Atividades criativas", imagem: atividadesCriativasImg, route: "/atividades_criativas" }, // Corrigido para string de rota
    { nome: "Socialização saudável", imagem: socializacaoSaudavelImg, route: "/socializacao_saudavel" }, // Corrigido para string de rota
    { nome: "Organização financeira", imagem: organizacaoFinanceiraImg, route: "/organizacao_financeira" } // Corrigido para string de rota
  ];

  return (
    <div className="carrossel-container" style={{
      display: 'flex',
      overflowX: 'auto', /* Permite rolagem horizontal se muitos itens */
      gap: '20px', /* Espaçamento entre os itens */
      paddingBottom: '10px', /* Espaço para a barra de rolagem */
      justifyContent: 'center', /* Centraliza os itens quando cabem */
      flexWrap: 'wrap' /* Permite quebrar linha em telas menores */
    }}>
      {/* Mapeia o array de categorias para renderizar cada item do carrossel */}
      {categorias.map((categoria, index) => (
        <Link
          key={index} // 'key' é importante para listas no React
          to={categoria.route} // Usa o Link do React Router para navegação interna
          className="carrossel-item" // Mantém a classe original para CSS externo, se houver
          title={categoria.nome}
          style={{
            textDecoration: 'none',
            color: 'inherit',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            minWidth: '150px',
            maxWidth: '180px',
            padding: '15px',
            backgroundColor: '#fff',
            borderRadius: '10px',
            boxShadow: '0 4px 8px ',
            transition: 'transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out',
            flexShrink: 0,
          }}
          // Efeitos de mouse hover para interatividade visual
          onMouseOver={(e) => { e.currentTarget.style.transform = 'scale(1.03)'; e.currentTarget.style.boxShadow = '0 6px 12px'; }}
          onMouseOut={(e) => { e.currentTarget.style.transform = 'scale(1)'; e.currentTarget.style.boxShadow = '0 4px 8px '; }}
        >
          <img
            src={categoria.imagem} // Usa a variável de imagem importada
            alt={categoria.nome}
            style={{
              width: '100px',
              height: '100px',
              objectFit: 'contain',
              marginBottom: '10px',
              borderRadius: '50%',
              border: '2px solid #ddd'
            }}
          />
          <p style={{ fontSize: '1.1em', fontWeight: 'bold', textAlign: 'center', margin: 0 }}>
            {categoria.nome}
          </p>
        </Link>
      ))}
    </div>
  );
};

export default CarrosselDeCategorias;
