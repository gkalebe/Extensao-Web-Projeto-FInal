import React from "react";
// Você pode importar outros componentes ou hooks aqui, como Link do react-router-dom, se necessário.

const Dashboard = () => {
  return (
    
    
    <div style={{ 
      padding: '30px', 
      backgroundColor: '#fff', 
      borderRadius: '15px', 
      boxShadow: '0 8px 24px rgba(0,0,0,0.1)', 
      minHeight: 'calc(100vh - 80px)', // Ajustado para dar mais espaço, considerando padding do App.js
      display: 'flex', 
      flexDirection: 'column', 
      alignItems: 'center', // Alinha o conteúdo verticalmente ao centro
      maxWidth: '900px', // Define uma largura máxima para o dashboard
      margin: '20px auto', // Centraliza o dashboard horizontalmente e adiciona margem vertical
      textAlign: 'center',
      fontFamily: 'Inter, sans-serif' // Usando a fonte Inter
    }}>
   
    
      
      <h1 style={{ color: '#4CAF50', fontSize: '2.8em', marginBottom: '25px', fontWeight: '700' }}>Dashboard do VidaU</h1> {/* Título mais genérico e estilos aprimorados */}
      <p style={{ fontSize: '1.3em', color: '#555', marginBottom: '30px' }}>
        Este é o seu painel de controle. Acompanhe seu progresso, defina novas metas e celebre suas conquistas!
      </p>
      

      {/* Seção de Metas Diárias */}
      <section style={{ 
        width: '100%', 
        marginBottom: '40px', 
        padding: '25px', 
        backgroundColor: '#e8f5e9', // Verde claro
        borderRadius: '10px', 
        boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
        textAlign: 'left' // Alinha o texto das seções à esquerda
      }}>
        <h2 style={{ color: '#2e7d32', fontSize: '2em', marginBottom: '20px' }}>Metas Diárias</h2>
        <ul style={{ listStyleType: 'none', padding: 0 }}>
          <li style={{ 
            backgroundColor: '#f0f4c3', // Amarelo claro
            padding: '12px 15px', 
            borderRadius: '8px', 
            marginBottom: '10px', 
            display: 'flex', 
            justifyContent: 'space-between', 
            alignItems: 'center',
            fontSize: '1.1em'
          }}>
            Meditar por 10 minutos
            <span style={{ color: '#4CAF50', fontWeight: 'bold' }}>Concluído</span>
          </li>
          <li style={{ 
            backgroundColor: '#e3f2fd', // Azul claro
            padding: '12px 15px', 
            borderRadius: '8px', 
            marginBottom: '10px', 
            display: 'flex', 
            justifyContent: 'space-between', 
            alignItems: 'center',
            fontSize: '1.1em'
          }}>
            Beber 2 litros de água
            <span style={{ color: '#FFC107', fontWeight: 'bold' }}>Pendente</span>
          </li>
          <li style={{ 
            backgroundColor: '#ffe0b2', // Laranja claro
            padding: '12px 15px', 
            borderRadius: '8px', 
            marginBottom: '10px', 
            display: 'flex', 
            justifyContent: 'space-between', 
            alignItems: 'center',
            fontSize: '1.1em'
          }}>
            Fazer 30 minutos de exercício
            <span style={{ color: '#FFC107', fontWeight: 'bold' }}>Pendente</span>
          </li>
        </ul>
        <button style={{
          backgroundColor: '#4CAF50',
          color: 'white',
          border: 'none',
          padding: '12px 25px',
          borderRadius: '8px',
          fontSize: '1.1em',
          fontWeight: 'bold',
          cursor: 'pointer',
          marginTop: '20px',
          transition: 'background-color 0.3s ease, transform 0.2s ease',
          boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
        }}
        onMouseOver={(e) => { e.currentTarget.style.backgroundColor = '#388e3c'; e.currentTarget.style.transform = 'translateY(-2px)'; }}
        onMouseOut={(e) => { e.currentTarget.style.backgroundColor = '#4CAF50'; e.currentTarget.style.transform = 'translateY(0)'; }}
        >
          Adicionar Nova Meta
        </button>
      </section>

      {/* Seção de Progresso Geral */}
      <section style={{ 
        width: '100%', 
        padding: '25px', 
        backgroundColor: '#e0f2f7', // Azul claro
        borderRadius: '10px', 
        boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
        textAlign: 'left' 
      }}>
        <h2 style={{ color: '#0288d1', fontSize: '2em', marginBottom: '20px' }}>Progresso Geral</h2>
        <div style={{ display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap', gap: '20px' }}>
          <div style={{ 
            backgroundColor: '#ffffff', 
            padding: '20px', 
            borderRadius: '10px', 
            boxShadow: '0 2px 6px rgba(0,0,0,0.08)', 
            flex: '1 1 calc(33% - 40px)', // Flexbox para 3 colunas responsivas
            minWidth: '200px',
            textAlign: 'center'
          }}>
            <p style={{ fontSize: '2.5em', fontWeight: 'bold', color: '#4CAF50', margin: '0 0 10px' }}>75%</p>
            <p style={{ fontSize: '1.1em', color: '#666', margin: 0 }}>Metas Concluídas (Semanal)</p>
          </div>
          <div style={{ 
            backgroundColor: '#ffffff', 
            padding: '20px', 
            borderRadius: '10px', 
            boxShadow: '0 2px 6px rgba(0,0,0,0.08)', 
            flex: '1 1 calc(33% - 40px)', 
            minWidth: '200px',
            textAlign: 'center'
          }}>
            <p style={{ fontSize: '2.5em', fontWeight: 'bold', color: '#FFC107', margin: '0 0 10px' }}>150</p>
            <p style={{ fontSize: '1.1em', color: '#666', margin: 0 }}>Dias Ativos</p>
          </div>
          <div style={{ 
            backgroundColor: '#ffffff', 
            padding: '20px', 
            borderRadius: '10px', 
            boxShadow: '0 2px 6px rgba(0,0,0,0.08)', 
            flex: '1 1 calc(33% - 40px)', 
            minWidth: '200px',
            textAlign: 'center'
          }}>
            <p style={{ fontSize: '2.5em', fontWeight: 'bold', color: '#007bff', margin: '0 0 10px' }}>Nível 5</p>
            <p style={{ fontSize: '1.1em', color: '#666', margin: 0 }}>Seu Nível de Bem-Estar</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Dashboard;
