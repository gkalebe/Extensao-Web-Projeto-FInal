import React from "react";
import { Link } from "react-router-dom"; // Importa o componente Link para navegação
import Navbar from './Navbar'; // Importa o componente Navbar

// Importa a imagem do botão de voltar. Ajuste o caminho './assets/'
// se a sua pasta de assets não estiver em 'src/pages/assets/'
import botaoVoltarImg from './assets/botao_voltar.webp';
import vidaULogo from './assets/VidaU_logo.png'; // Caminho ajustado


// Você pode importar uma imagem principal para esta página, se houver
// import escritaPessoalMainImg from './assets/Escrita_pessoal.png'; // Descomente e use se tiver uma imagem principal para a página

const EscritaPessoal = () => { // Nome do componente corrigido para PascalCase
  return (
    // Fragmento React para envolver o conteúdo
    <>
    <header className="menu"> {/* class para className */}
                <div className="logo"> {/* class para className */}
                  <Link to="/"> {/* Usando Link para navegação interna */}
                    <img src={vidaULogo} alt="VidaU Logo" style={{ maxWidth: '100px' }} /> {/* Usando a variável importada */}
                  </Link>
                </div>
                
              </header>
     <Navbar /> {/* A Navbar será exibida no topo da página do Dashboard */}
      <main>
        {/* Conteúdo do Dashboard */}
        <h1></h1>
        {/* ... */}
      </main>
      {/*
        As tags <div id="navbar"></div> e o <script src="navbar-loader.js"></script>
        foram removidas. Em React, o Navbar seria um componente importado e renderizado
        diretamente aqui ou em um layout pai (como o App.js).
        Por exemplo: <Navbar /> (se você tiver um componente Navbar importado).
      */}
      <main className="content-container" style={{ maxWidth: '800px', margin: '40px auto', padding: '20px', backgroundColor: '#fff', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
        <h1 style={{ textAlign: 'center', color: '#8b4513', marginBottom: '30px', fontSize: '2.5em' }}>Escrita pessoal: uma conversa íntima com você mesmo</h1>

        {/* Se houver uma imagem principal para a página, você pode adicioná-la aqui
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <img src={escritaPessoalMainImg} alt="Escrita Pessoal Ilustração" style={{ maxWidth: '100%', height: 'auto', borderRadius: '10px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' }} />
        </div>
        */}

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>1. Introdução</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            Escrever sobre seus pensamentos, emoções e experiências é uma poderosa ferramenta para se conhecer melhor, organizar ideias e aliviar o estresse.
          </p>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>2. Benefícios da escrita pessoal</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>A prática regular da escrita traz diversos benefícios, como:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Melhora da saúde mental e emocional</li>
            <li>Clareza para tomar decisões e resolver problemas</li>
            <li>Estímulo da criatividade e imaginação</li>
            <li>Registro de memórias e aprendizados importantes</li>
            <li>Desenvolvimento da autoestima e autocompaixão</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>3. Dicas para começar a escrever</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>Para iniciar sua prática de escrita:</p>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Reserve alguns minutos do dia para escrever sem se preocupar com regras</li>
            <li>Use um diário, caderno ou aplicativo digital, o que for mais confortável</li>
            <li>Escreva sobre seus sentimentos, metas, desafios ou momentos felizes</li>
            <li>Experimente diferentes estilos: diário, cartas, poesia ou listas</li>
            <li>Não julgue o que escreve, permita-se ser autêntico e livre</li>
          </ul>
        </section>

        <section style={{ marginBottom: '20px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>4. Exercícios simples para praticar</h2>
          <ul style={{ listStyleType: 'disc', marginLeft: '20px', fontSize: '1.1em' }}>
            <li>Escreva uma carta para você mesmo: expresse apoio e reconhecimento.</li>
            <li>Liste três coisas pelas quais você é grato hoje.</li>
            <li>Descreva um desafio que superou e o que aprendeu com ele.</li>
            <li>Registre seus sonhos e planos para o futuro.</li>
          </ul>
        </section>

        <section style={{ marginBottom: '30px' }}>
          <h2 style={{ color: '#007bff', fontSize: '1.8em', marginBottom: '10px' }}>5. Motivação</h2>
          <p style={{ lineHeight: '1.6', fontSize: '1.1em' }}>
            A escrita pessoal é um espaço seguro para você crescer, se curar e celebrar suas conquistas. No VidaU, queremos incentivar você a transformar palavras em autoconhecimento e bem-estar.
          </p>
        </section>

        <div className="botao-voltar" style={{ textAlign: 'center', marginTop: '40px' }}>
          <Link to="/" className="btn-voltar" style={{
            display: 'inline-flex',
            alignItems: 'center',
            padding: '12px 25px',
            backgroundColor: '#007bff',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '5px',
            fontSize: '1.1em',
            fontWeight: 'bold',
            transition: 'background-color 0.3s ease'
          }}>
            <img src={botaoVoltarImg} alt="Voltar" style={{ width: '20px', height: '20px', marginRight: '10px' }}/>
            Voltar para Início
          </Link>
        </div>
      </main>
    </>
  );
};

export default EscritaPessoal; // Exporta o componente com o nome corrigido
